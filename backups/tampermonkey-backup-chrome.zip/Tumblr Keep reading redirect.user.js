// ==UserScript==
// @name               Tumblr Keep reading redirect
// @namespace          sean
// @match              https://www.tumblr.com/*
// @grant              none
// @version            1.0
// @run-at             document-start
// @author             sean
// @description        Redirect "Keep reading" and "Expand" links
// @license            GPL-3.0
// ==/UserScript==

'use strict';

const handleClick = e => {
    // Only act on dashboard or likes pages
    if (
        !window.location.pathname.startsWith("/dashboard") &&
        window.location.pathname !== '/likes'
    ) return;

    // Only handle clicks on SPANs with specific text
    if (e.target.tagName !== 'SPAN') return;

    const text = e.target.textContent.trim();
    if (text !== 'Keep reading' && text !== 'Expand') return;

    // Get the parent article and header link
    const article = e.target.closest('article');
    if (!article) return;

    const link = article.querySelector('header a');
    if (!link || !link.href) return;

    const href = link.getAttribute('href');

    e.preventDefault();
    e.stopPropagation();
    window.location.href = href;
};

document.addEventListener('click', handleClick, true);