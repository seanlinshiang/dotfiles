flatpak install --system com.github.Matoking.protontricks -y
flatpak install --system com.mattjakeman.ExtensionManager -y
flatpak install --system com.spotify.Client -y
flatpak install --system io.github.vikdevelop.SaveDesktop -y
flatpak install --system net.davidotek.pupgui2 -y
flatpak install --system org.localsend.localsend_app -y
