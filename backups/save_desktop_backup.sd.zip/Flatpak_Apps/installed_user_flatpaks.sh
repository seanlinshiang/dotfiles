flatpak install --user com.github.Matoking.protontricks -y
flatpak install --user com.usebottles.bottles -y
flatpak install --user net.davidotek.pupgui2 -y
flatpak install --user ca.desrt.dconf-editor -y
