flatpak install --user com.github.wwmm.easyeffects -y
flatpak install --user com.usebottles.bottles -y
